# riptide
Reaction Inclusion by Parsimonious usage, Transcript Distribution, and Exploration of topology
