# riptide
Reaction Inclusion by Parsimonious usage and Transcript Distribution
